# Vanta Helix

**P-NETRATOR**  
Premium Cyber Platform / Network Ops / Response

## Charakter
Signal. Correlate. Strike.

## Enthalten
- logo_wordmark.png
- logo_wordmark_transparent.png
- logo_wordmark.svg
- banner_1600x500.png
- icon_1024.png
- icon.svg
- favicon.ico
- brand_tokens.json
- preview_board.png

## Empfehlung
Petri-Network – Advanced Security Automation & Response
