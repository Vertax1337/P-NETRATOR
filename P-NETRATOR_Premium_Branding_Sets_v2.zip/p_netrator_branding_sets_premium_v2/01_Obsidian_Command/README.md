# Obsidian Command

**P-NETRATOR**  
Premium Red-Team / Operator / Tactical Control

## Charakter
Precision over noise.

## Enthalten
- logo_wordmark.png
- logo_wordmark_transparent.png
- logo_wordmark.svg
- banner_1600x500.png
- icon_1024.png
- icon.svg
- favicon.ico
- brand_tokens.json
- preview_board.png

## Empfehlung
Petri-Network – Red-Team Automation, Tactics, Operations & Response
